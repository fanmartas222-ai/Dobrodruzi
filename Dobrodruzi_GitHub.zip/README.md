# DOBRODRUZI

Rodinná turistická sběratelská hra. Objevujte nová místa, odemykejte tvory a společně budujte sbírku dobrodruhů.

## Co funguje v tomto prvním prototypu
- Mapa OpenStreetMap a zjištění aktuální GPS polohy.
- Objevení náhodného tvora na novém místě (alespoň 500 m od předchozího objevu).
- Společná sbírka tvorů a turistická hodnost.
- Import GPX waypointů (např. kešek exportovaných z c:geo).

## Omezení
- Toto je první hratelný prototyp, nikoli dokončená hra.
- Tvorové se zatím vybírají náhodně; nejsou navázáni na skutečné druhy ani konkrétní geografické lokality.
- Data se ukládají pouze v tomto prohlížeči/telefonu. Neexistuje synchronizace mezi telefony. Nevymazávejte data prohlížeče, pokud chcete sbírku zachovat.
- GPX import zobrazuje waypointy; navigace a logování keší zůstává v c:geo.
- Mapový podklad je OpenStreetMap, nikoli Mapy.com.

## Zveřejnění
V GitHubu otevřete Settings → Pages. Jako zdroj zvolte Deploy from a branch, větev main a složku /(root), poté Save. Po publikaci otevřete adresu GitHub Pages a v Chrome na Androidu zvolte Instalovat aplikaci / Přidat na plochu.
